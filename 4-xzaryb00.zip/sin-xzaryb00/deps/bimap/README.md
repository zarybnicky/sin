Original repository: https://github.com/joelwilliamson/bimap
